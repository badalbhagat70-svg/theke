from http.server import BaseHTTPRequestHandler
import json
import datetime
import os
import sqlite3

DB_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "attendance.db")

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/health':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "ok", "platform": "vercel"}).encode('utf-8'))
            return
        elif self.path == '/api/time':
            ist_tz = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
            now_ist = datetime.datetime.now(ist_tz)
            now_utc = datetime.datetime.now(datetime.timezone.utc)
            resp_data = {
                "success": True,
                "iso_utc": now_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "date_ist": now_ist.strftime("%Y-%m-%d"),
                "time_ist": now_ist.strftime("%H:%M:%S"),
                "time_24_ist": now_ist.strftime("%H:%M"),
                "year_month": now_ist.strftime("%Y-%m-%d")[:7],
                "timestamp_ms": int(now_ist.timestamp() * 1000)
            }
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(resp_data).encode('utf-8'))
            return
        elif self.path == '/api/full-store':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps({}).encode('utf-8'))
            return
            
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps({"success": True}).encode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()
